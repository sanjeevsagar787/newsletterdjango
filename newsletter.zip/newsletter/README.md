# Build any blog with Django

[![alt text](https://github.com/justdjango/dream_blog/blob/master/thumbnail.png "Logo")](https://youtu.be/HWg3zXWwre8)

This [tutorial series](https://youtu.be/HWg3zXWwre8) shows how to connect any HTML blog template to Django, leaving you with an awesome looking, fully-functional blog.

Get the original HTML template [here](https://bootstrapious.com/p/bootstrap-blog)
